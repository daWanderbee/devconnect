module.exports = {
  extends: ["custom/react-internal"],
  rules: {
    "import/no-default-export": "off",
    "tsdoc/syntax": "off"
  },
};
