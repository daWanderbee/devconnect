module.exports = {
  extends: ['custom/react-internal'],
  rules: {
    'eslint-comments/require-description': 'off',
    'no-console': 'off',
  },
};
