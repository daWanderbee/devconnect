export default ["packages/*"];
