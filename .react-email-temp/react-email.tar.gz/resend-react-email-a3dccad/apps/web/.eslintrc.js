module.exports = {
  extends: ['custom/next'],
};
